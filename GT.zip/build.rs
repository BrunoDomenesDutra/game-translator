fn main() {
    embed_resource::compile("icon.rc", embed_resource::NONE);
}