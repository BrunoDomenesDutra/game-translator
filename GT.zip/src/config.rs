// game-translator/src/config.rs

// ============================================================================
// MÓDULO CONFIG - Configurações da aplicação
// ============================================================================

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};
use std::env;
use std::fs;
use std::path::Path;

/// Estrutura de configuração da região de captura
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RegionConfig {
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
}

impl Default for RegionConfig {
    fn default() -> Self {
        RegionConfig {
            x: 0,
            y: 0,
            width: 1920,
            height: 1080,
        }
    }
}

/// Estrutura de configuração do overlay
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OverlayConfig {
    pub x: u32,
    pub y: u32,
    pub width: u32,
    pub height: u32,
    pub background_type: String,
    pub background_color: [u8; 4],
    pub background_image_path: String,
    /// Se true, mostra fundo preto semi-transparente. Se false, só texto com contorno.
    pub show_background: bool,
}

impl Default for OverlayConfig {
    fn default() -> Self {
        OverlayConfig {
            x: 400,
            y: 100,
            width: 1200,
            height: 200,
            background_type: "solid".to_string(),
            background_color: [0, 0, 0, 235],
            background_image_path: "backgrounds/custom.png".to_string(),
            show_background: false, // Padrão: só texto com contorno
        }
    }
}

/// Um atalho de teclado: modificador opcional + tecla principal.
/// Exemplo: { "modifier": "Ctrl", "key": "T" } ou { "modifier": "", "key": "Numpad0" }
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HotkeyBinding {
    /// Modificador: "" (nenhum), "Ctrl", "Shift", "Alt"
    #[serde(default)]
    pub modifier: String,
    /// Tecla principal: "Numpad0", "F1", "A", "B", etc.
    pub key: String,
}

impl HotkeyBinding {
    /// Cria um binding sem modificador (compatível com o formato antigo)
    pub fn key_only(key: &str) -> Self {
        HotkeyBinding {
            modifier: String::new(),
            key: key.to_string(),
        }
    }

    /// Cria um binding com modificador
    #[allow(dead_code)]
    pub fn with_modifier(modifier: &str, key: &str) -> Self {
        HotkeyBinding {
            modifier: modifier.to_string(),
            key: key.to_string(),
        }
    }

    /// Retorna uma string legível pro usuário: "Ctrl + T" ou "Numpad0"
    #[allow(dead_code)]
    pub fn display_name(&self) -> String {
        if self.modifier.is_empty() {
            self.key.clone()
        } else {
            format!("{} + {}", self.modifier, self.key)
        }
    }
}

/// Estrutura de configuração das hotkeys
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HotkeyConfig {
    pub translate_fullscreen: HotkeyBinding,
    pub translate_region: HotkeyBinding,
    pub select_region: HotkeyBinding,
    pub select_subtitle_region: HotkeyBinding,
    pub toggle_subtitle_mode: HotkeyBinding,
    pub hide_translation: HotkeyBinding,
    /// Atalho pra abrir configurações (sempre Numpad5 por padrão)
    #[serde(default = "default_open_settings_binding")]
    pub open_settings: HotkeyBinding,
}

fn default_open_settings_binding() -> HotkeyBinding {
    HotkeyBinding::key_only("Numpad5")
}

impl Default for HotkeyConfig {
    fn default() -> Self {
        HotkeyConfig {
            translate_fullscreen: HotkeyBinding::key_only("NumpadSubtract"),
            translate_region: HotkeyBinding::key_only("NumpadAdd"),
            select_region: HotkeyBinding::key_only("NumpadMultiply"),
            select_subtitle_region: HotkeyBinding::key_only("NumpadDivide"),
            toggle_subtitle_mode: HotkeyBinding::key_only("Numpad0"),
            hide_translation: HotkeyBinding::key_only("NumpadDecimal"),
            open_settings: HotkeyBinding::key_only("Numpad5"),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ShadowConfig {
    pub enabled: bool,
    pub offset_x: i32,
    pub offset_y: i32,
    pub color: [u8; 4], // RGBA
    pub blur: u32,
}

impl Default for ShadowConfig {
    fn default() -> Self {
        ShadowConfig {
            enabled: false,
            offset_x: 2,
            offset_y: 2,
            color: [0, 0, 0, 180],
            blur: 0,
        }
    }
}

/// Configuração de contorno do texto
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutlineConfig {
    pub enabled: bool,
    pub width: u32,
    pub color: [u8; 4], // RGBA
}

impl Default for OutlineConfig {
    fn default() -> Self {
        OutlineConfig {
            enabled: false,
            width: 2,
            color: [0, 0, 0, 255],
        }
    }
}

/// Configuração completa de fonte
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FontConfig {
    /// Nome do arquivo .ttf na pasta fonts/ para as traduções
    /// Ex: "Roboto-Regular.ttf", "NotoSans-Bold.ttf"
    /// Se vazio ou arquivo não encontrado, usa fonte padrão do programa
    #[serde(default = "default_translation_font")]
    pub translation_font: String,
    /// Campos legados mantidos para compatibilidade (ignorados)
    #[serde(default)]
    pub font_type: String,
    #[serde(default)]
    pub system_font_name: String,
    #[serde(default)]
    pub file_path: String,
    pub size: f32,
    pub color: [u8; 4], // RGBA
    pub shadow: ShadowConfig,
    pub outline: OutlineConfig,
}

fn default_translation_font() -> String {
    "Roboto-Regular.ttf".to_string()
}

impl Default for FontConfig {
    fn default() -> Self {
        FontConfig {
            translation_font: "Roboto-Regular.ttf".to_string(),
            font_type: String::new(),
            system_font_name: String::new(),
            file_path: String::new(),
            size: 32.0,
            color: [255, 255, 255, 255],
            shadow: ShadowConfig::default(),
            outline: OutlineConfig::default(),
        }
    }
}

/// Estrutura de configuração de exibição
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DisplayConfig {
    /// Duração da exibição do overlay em segundos
    pub overlay_duration_secs: u64,
    /// Usar captura em memória (mais rápido)
    pub use_memory_capture: bool,
    /// Habilitar TTS
    pub tts_enabled: bool,
    /// Pré-processamento de imagem para OCR
    pub preprocess: PreprocessConfig,
}

/// Estrutura de configuração de tradução
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TranslationConfig {
    /// Provedor de tradução: "deepl", "google" ou "libretranslate"
    pub provider: String,
    /// Idioma de origem (ex: "EN", "JA", "auto")
    pub source_language: String,
    /// Idioma de destino (ex: "PT-BR", "PT", "ES")
    pub target_language: String,
    /// URL do LibreTranslate (se usar LibreTranslate local)
    #[serde(default = "default_libretranslate_url")]
    pub libretranslate_url: String,
    /// API key do DeepL
    #[serde(default)]
    pub deepl_api_key: String,
    /// API key do ElevenLabs (TTS)
    #[serde(default)]
    pub elevenlabs_api_key: String,
    /// Voice ID do ElevenLabs
    #[serde(default)]
    pub elevenlabs_voice_id: String,
}

/// URL padrão do LibreTranslate
fn default_libretranslate_url() -> String {
    "http://localhost:5000".to_string()
}

impl Default for TranslationConfig {
    fn default() -> Self {
        TranslationConfig {
            provider: "libretranslate".to_string(),
            source_language: "EN".to_string(),
            target_language: "PT-BR".to_string(),
            libretranslate_url: "http://localhost:5000".to_string(),
            deepl_api_key: String::new(),
            elevenlabs_api_key: String::new(),
            elevenlabs_voice_id: String::new(),
        }
    }
}

/// Configuração de pré-processamento de imagem para OCR
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PreprocessConfig {
    /// Habilita pré-processamento
    pub enabled: bool,
    /// Converte para escala de cinza
    pub grayscale: bool,
    /// Inverte cores (branco <-> preto)
    pub invert: bool,
    /// Fator de contraste (1.0 = normal, >1 = mais contraste)
    pub contrast: f32,
    /// Threshold para binarização (0-255, 0 = desabilitado)
    /// Pixels acima do threshold = branco, abaixo = preto
    pub threshold: u8,
    /// Salva imagem processada para debug
    pub save_debug_image: bool,
    /// Fator de upscale antes do OCR (1.0 = sem escala, 2.0 = dobro, 3.0 = triplo)
    /// Texto pequeno (<20px) se beneficia muito de 2.0 ou 3.0
    /// Valores acima de 3.0 não são recomendados (mais lento sem ganho)
    #[serde(default = "default_upscale")]
    pub upscale: f32,
    /// Blur gaussiano antes do threshold (0 = desativado, 1-5 = leve a forte)
    /// Suaviza sombras e artefatos visuais do texto antes da binarização.
    /// Valores recomendados: 0 (desativado) ou 1-2 (leve)
    /// Valores altos (3+) podem borrar texto fino demais
    #[serde(default)]
    pub blur: f32,
    /// Dilatação: "engorda" os caracteres (pixels brancos se expandem)
    /// Útil quando as letras ficam finas demais após threshold.
    /// 0 = desativado, 1-3 = leve a forte
    #[serde(default)]
    pub dilate: u8,
    /// Erosão: "afina" os caracteres (remove pixels das bordas)
    /// Útil para remover ruído pequeno ao redor do texto.
    /// 0 = desativado, 1-3 = leve a forte
    #[serde(default)]
    pub erode: u8,
    /// Modo de detecção de bordas (edge detection)
    /// Detecta contornos de texto em vez de usar threshold simples.
    /// Muito melhor para texto branco com outline em fundo claro.
    /// 0 = desativado, 1-255 = threshold do gradiente (recomendado: 30-80)
    #[serde(default)]
    pub edge_detection: u8,
}

/// Valor padrão do upscale (1.0 = desativado, sem escala)
fn default_upscale() -> f32 {
    1.0
}

impl Default for PreprocessConfig {
    fn default() -> Self {
        PreprocessConfig {
            enabled: false,
            grayscale: true,
            invert: true,
            contrast: 1.5,
            threshold: 0,
            save_debug_image: false,
            upscale: 1.0,
            blur: 0.0, // 0.0 = desativado
            dilate: 0,
            erode: 0,
            edge_detection: 0,
        }
    }
}

/// Estrutura de configuração de legendas em tempo real
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SubtitleConfig {
    /// Região onde as legendas originais aparecem no jogo
    pub region: RegionConfig,
    /// Intervalo entre capturas em milissegundos
    pub capture_interval_ms: u64,
    /// Tempo mínimo de exibição da tradução (segundos)
    pub min_display_secs: u64,
    /// Tempo máximo de exibição da tradução (segundos)
    pub max_display_secs: u64,
    /// Configuração de fonte específica para legendas
    pub font: FontConfig,
    /// Número máximo de legendas visíveis
    pub max_lines: usize,
    /// Pré-processamento de imagem para OCR
    pub preprocess: PreprocessConfig,
}

impl Default for SubtitleConfig {
    fn default() -> Self {
        SubtitleConfig {
            region: RegionConfig {
                x: 400,
                y: 900,
                width: 1200,
                height: 100,
            },
            capture_interval_ms: 1000,
            min_display_secs: 2,
            max_display_secs: 10,
            font: FontConfig {
                translation_font: "Roboto-Regular.ttf".to_string(),
                font_type: String::new(),
                system_font_name: String::new(),
                file_path: String::new(),
                size: 24.0,
                color: [255, 255, 255, 255],
                shadow: ShadowConfig::default(),
                outline: OutlineConfig::default(),
            },
            max_lines: 3,
            preprocess: PreprocessConfig::default(),
        }
    }
}

impl Default for DisplayConfig {
    fn default() -> Self {
        DisplayConfig {
            overlay_duration_secs: 10,
            use_memory_capture: true,
            tts_enabled: false,
            preprocess: PreprocessConfig::default(),
        }
    }
}

/// Configuração da OpenAI para tradução com IA
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OpenAIConfig {
    /// API key da OpenAI
    #[serde(default)]
    pub api_key: String,

    /// Modelo a usar (ex: "gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo")
    #[serde(default = "default_openai_model")]
    pub model: String,

    /// Temperature: controla criatividade (0.0 = literal, 1.0+ = criativo)
    /// Para tradução, valores baixos (0.1-0.4) são melhores
    #[serde(default = "default_openai_temperature")]
    pub temperature: f32,

    /// Máximo de tokens na resposta
    #[serde(default = "default_openai_max_tokens")]
    pub max_tokens: u32,

    /// System prompt: instrução completa para o modelo
    /// Define como a IA deve traduzir (tom, estilo, regras)
    #[serde(default = "default_openai_system_prompt")]
    pub system_prompt: String,

    /// Limite de requests por sessão (0 = ilimitado)
    /// Quando atingir, cai para o fallback_provider
    #[serde(default = "default_openai_max_requests")]
    pub max_requests_per_session: u32,

    /// Provedor de fallback quando OpenAI falha ou atinge limite
    /// Opções: "google", "deepl", "libretranslate"
    #[serde(default = "default_openai_fallback")]
    pub fallback_provider: String,

    /// Quantas legendas anteriores enviar como contexto (0 = desativado)
    /// Ajuda a IA a manter coerência no diálogo
    #[serde(default = "default_openai_context_lines")]
    pub context_lines: u32,

    /// Informações sobre o jogo (nome, gênero, etc.)
    /// Ajuda a IA a traduzir nomes e termos corretamente
    #[serde(default)]
    pub game_context: String,
}

fn default_openai_model() -> String {
    "gpt-4o-mini".to_string()
}

fn default_openai_temperature() -> f32 {
    0.3
}

fn default_openai_max_tokens() -> u32 {
    1024
}

fn default_openai_max_requests() -> u32 {
    0 // 0 = ilimitado
}

fn default_openai_fallback() -> String {
    "google".to_string()
}

fn default_openai_context_lines() -> u32 {
    5
}

pub fn default_openai_system_prompt() -> String {
    r#"Você é um tradutor profissional de LEGENDAS DE JOGOS.

Contexto:
- Jogo com temática Yakuza / crime japonês
- Diálogos urbanos, adultos, cheios de gírias
- Tom natural, coloquial, brasileiro

Regras OBRIGATÓRIAS:
- Traduza para PORTUGUÊS DO BRASIL
- Priorize LOCALIZAÇÃO, não tradução literal
- Use gírias brasileiras equivalentes quando fizer sentido
- Mantenha palavrões quando existirem
- Não suavize o tom
- Preserve nomes próprios e honoríficos (-san, -kun, -sensei)
- Preserve placeholders ({}, %s, %d)
- Preserve quebras de linha
- Preserve pontuação dramática (… — ! ?)

Formato de saída:
- Retorne APENAS um JSON array de strings
- Mesma ordem do input
- Sem comentários, sem explicações"#
        .to_string()
}

impl Default for OpenAIConfig {
    fn default() -> Self {
        OpenAIConfig {
            api_key: String::new(),
            model: default_openai_model(),
            temperature: default_openai_temperature(),
            max_tokens: default_openai_max_tokens(),
            system_prompt: default_openai_system_prompt(),
            max_requests_per_session: default_openai_max_requests(),
            fallback_provider: default_openai_fallback(),
            context_lines: default_openai_context_lines(),
            game_context: String::new(),
        }
    }
}

/// Estrutura principal de configuração
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AppConfig {
    pub region: RegionConfig,
    pub overlay: OverlayConfig,
    pub font: FontConfig,
    pub hotkeys: HotkeyConfig,
    pub display: DisplayConfig,
    pub translation: TranslationConfig,
    pub subtitle: SubtitleConfig,
    pub openai: OpenAIConfig,
}

impl Default for AppConfig {
    fn default() -> Self {
        AppConfig {
            region: RegionConfig::default(),
            overlay: OverlayConfig::default(),
            font: FontConfig::default(),
            hotkeys: HotkeyConfig::default(),
            display: DisplayConfig::default(),
            translation: TranslationConfig::default(),
            subtitle: SubtitleConfig::default(),
            openai: OpenAIConfig::default(),
        }
    }
}

impl AppConfig {
    /// Caminho do arquivo de configuração
    const CONFIG_FILE: &'static str = "config.json";

    /// Carrega configurações do arquivo (ou cria um padrão se não existir)
    pub fn load() -> Result<Self> {
        info!("📋 Carregando configurações...");

        if Path::new(Self::CONFIG_FILE).exists() {
            // Carrega do arquivo existente
            let contents =
                fs::read_to_string(Self::CONFIG_FILE).context("Falha ao ler config.json")?;

            let config: AppConfig =
                serde_json::from_str(&contents).context("Falha ao parsear config.json")?;

            info!("✅ Configurações carregadas de config.json");
            info!(
                "   📍 Região: {}x{} na posição ({}, {})",
                config.region.width, config.region.height, config.region.x, config.region.y
            );
            info!(
                "   🖼️  Overlay: {}x{} na posição ({}, {})",
                config.overlay.width, config.overlay.height, config.overlay.x, config.overlay.y
            );

            Ok(config)
        } else {
            // Cria arquivo padrão
            warn!("⚠️  config.json não encontrado, criando arquivo padrão...");
            let config = AppConfig::default();
            config.save()?;
            info!("✅ config.json criado com valores padrão");
            Ok(config)
        }
    }

    /// Salva configurações no arquivo
    pub fn save(&self) -> Result<()> {
        info!("💾 Salvando configurações...");

        let json =
            serde_json::to_string_pretty(self).context("Falha ao serializar configurações")?;

        fs::write(Self::CONFIG_FILE, json).context("Falha ao escrever config.json")?;

        info!("✅ Configurações salvas em config.json");

        Ok(())
    }

    /// Atualiza a região de captura e salva
    pub fn update_region(&mut self, x: u32, y: u32, width: u32, height: u32) -> Result<()> {
        info!("🔄 Atualizando região de captura...");

        self.region.x = x;
        self.region.y = y;
        self.region.width = width;
        self.region.height = height;

        self.save()?;

        info!(
            "✅ Região atualizada: {}x{} na posição ({}, {})",
            width, height, x, y
        );

        Ok(())
    }
}

/// Estrutura que guarda todas as configurações da aplicação (compatibilidade)
#[derive(Debug, Clone)]
pub struct Config {
    /// API key do DeepL para tradução
    #[allow(dead_code)]
    pub deepl_api_key: String,

    /// API key do ElevenLabs para TTS
    #[allow(dead_code)]
    pub elevenlabs_api_key: String,

    /// ID da voz no ElevenLabs
    #[allow(dead_code)]
    pub elevenlabs_voice_id: String,

    /// Configurações da aplicação
    pub app_config: AppConfig,

    // Atalhos para acessar facilmente (retrocompatibilidade)
    pub region_x: u32,
    pub region_y: u32,
    pub region_width: u32,
    pub region_height: u32,
}

impl Config {
    /// Carrega as configurações completas
    pub fn load() -> Result<Self> {
        info!("📋 Carregando configurações completas...");

        // Carrega variáveis de ambiente (.env) como fallback
        // dotenv::dotenv().ok();

        // Carrega config.json primeiro
        let app_config = AppConfig::load()?;

        // API keys: prioriza config.json, fallback pro .env
        let deepl_api_key = if !app_config.translation.deepl_api_key.is_empty() {
            app_config.translation.deepl_api_key.clone()
        } else {
            env::var("DEEPL_API_KEY").unwrap_or_else(|_| {
                warn!("⚠️  DEEPL_API_KEY não configurada");
                String::new()
            })
        };

        let elevenlabs_api_key = if !app_config.translation.elevenlabs_api_key.is_empty() {
            app_config.translation.elevenlabs_api_key.clone()
        } else {
            env::var("ELEVENLABS_API_KEY").unwrap_or_else(|_| String::new())
        };

        let elevenlabs_voice_id = if !app_config.translation.elevenlabs_voice_id.is_empty() {
            app_config.translation.elevenlabs_voice_id.clone()
        } else {
            env::var("ELEVENLABS_VOICE_ID").unwrap_or_else(|_| String::new())
        };

        info!("✅ Configurações carregadas!");

        // Status das API keys
        if deepl_api_key == "fake-api-key" {
            info!("   🌐 DeepL: ❌ Não configurado (modo fake)");
        } else {
            let masked_key = format!("{}...", &deepl_api_key[..8.min(deepl_api_key.len())]);
            info!("   🌐 DeepL: ✅ Configurado ({})", masked_key);
        }

        if elevenlabs_api_key.is_empty() {
            info!("   🔊 ElevenLabs: ⏸️  Não configurado");
        } else {
            info!("   🔊 ElevenLabs: ✅ Configurado");
        }

        info!(
            "   📸 Captura: 🎯 Região customizada ({}x{} na posição {},{})",
            app_config.region.width,
            app_config.region.height,
            app_config.region.x,
            app_config.region.y
        );

        Ok(Config {
            deepl_api_key,
            elevenlabs_api_key,
            elevenlabs_voice_id,

            // Atalhos para retrocompatibilidade
            region_x: app_config.region.x,
            region_y: app_config.region.y,
            region_width: app_config.region.width,
            region_height: app_config.region.height,

            app_config,
        })
    }
}
